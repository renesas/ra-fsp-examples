/* generated HAL source file - do not edit */
#include "hal_data.h"
static const timer_api_t g_timer_periodic_nsc_api =
{
    .close = g_timer_periodic_close_guard,
    .periodSet = g_timer_periodic_period_set_guard,
    .dutyCycleSet = g_timer_periodic_duty_cycle_set_guard,
    .reset = g_timer_periodic_reset_guard,
    .start = g_timer_periodic_start_guard,
    .enable = g_timer_periodic_enable_guard,
    .disable = g_timer_periodic_disable_guard,
    .infoGet = g_timer_periodic_info_get_guard,
    .statusGet = g_timer_periodic_status_get_guard,
    .stop = g_timer_periodic_stop_guard,
    .open = g_timer_periodic_open_guard,
    .callbackSet = g_timer_periodic_callback_set_guard,
};
const timer_instance_t g_timer_periodic =
{
    .p_api = &g_timer_periodic_nsc_api,
    .p_ctrl = FSP_SECURE_ARGUMENT,
    .p_cfg = FSP_SECURE_ARGUMENT,
};
static const timer_api_t g_timer_one_shot_nsc_api =
{
    .close = g_timer_one_shot_close_guard,
    .periodSet = g_timer_one_shot_period_set_guard,
    .dutyCycleSet = g_timer_one_shot_duty_cycle_set_guard,
    .reset = g_timer_one_shot_reset_guard,
    .start = g_timer_one_shot_start_guard,
    .enable = g_timer_one_shot_enable_guard,
    .disable = g_timer_one_shot_disable_guard,
    .infoGet = g_timer_one_shot_info_get_guard,
    .statusGet = g_timer_one_shot_status_get_guard,
    .stop = g_timer_one_shot_stop_guard,
    .open = g_timer_one_shot_open_guard,
    .callbackSet = g_timer_one_shot_callback_set_guard,
};
const timer_instance_t g_timer_one_shot =
{
    .p_api = &g_timer_one_shot_nsc_api,
    .p_ctrl = FSP_SECURE_ARGUMENT,
    .p_cfg = FSP_SECURE_ARGUMENT,
};
void g_hal_init(void) {
g_common_init();
}
