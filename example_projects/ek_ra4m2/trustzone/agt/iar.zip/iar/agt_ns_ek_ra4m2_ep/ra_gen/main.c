/* generated main source file - do not edit */
#include "hal_data.h"
            int main(void) {
              hal_entry();
              return 0;
            }
