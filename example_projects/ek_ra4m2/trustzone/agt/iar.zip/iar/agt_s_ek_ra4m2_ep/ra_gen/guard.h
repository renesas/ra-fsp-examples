/* generated guard header file - do not edit */
#ifndef GUARD_H_
#define GUARD_H_
#include "hal_data.h"
BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_one_shot_close_guard(timer_ctrl_t *const p_ctrl);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_one_shot_period_set_guard(timer_ctrl_t *const p_ctrl, uint32_t const period_counts);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_one_shot_duty_cycle_set_guard(timer_ctrl_t *const p_ctrl, uint32_t const duty_cycle_counts, uint32_t const pin);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_one_shot_reset_guard(timer_ctrl_t *const p_ctrl);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_one_shot_start_guard(timer_ctrl_t *const p_ctrl);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_one_shot_enable_guard(timer_ctrl_t *const p_ctrl);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_one_shot_disable_guard(timer_ctrl_t *const p_ctrl);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_one_shot_info_get_guard(timer_ctrl_t *const p_ctrl, timer_info_t *const p_info);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_one_shot_status_get_guard(timer_ctrl_t *const p_ctrl, timer_status_t *const p_status);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_one_shot_stop_guard(timer_ctrl_t *const p_ctrl);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_one_shot_open_guard(timer_ctrl_t *const p_ctrl, timer_cfg_t const *const p_cfg);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_one_shot_callback_set_guard(timer_ctrl_t *const p_api_ctrl, void(*p_callback)(timer_callback_args_t *), void const *const p_context, timer_callback_args_t *const p_callback_memory);
BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_periodic_close_guard(timer_ctrl_t *const p_ctrl);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_periodic_period_set_guard(timer_ctrl_t *const p_ctrl, uint32_t const period_counts);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_periodic_duty_cycle_set_guard(timer_ctrl_t *const p_ctrl, uint32_t const duty_cycle_counts, uint32_t const pin);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_periodic_reset_guard(timer_ctrl_t *const p_ctrl);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_periodic_start_guard(timer_ctrl_t *const p_ctrl);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_periodic_enable_guard(timer_ctrl_t *const p_ctrl);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_periodic_disable_guard(timer_ctrl_t *const p_ctrl);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_periodic_info_get_guard(timer_ctrl_t *const p_ctrl, timer_info_t *const p_info);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_periodic_status_get_guard(timer_ctrl_t *const p_ctrl, timer_status_t *const p_status);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_periodic_stop_guard(timer_ctrl_t *const p_ctrl);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_periodic_open_guard(timer_ctrl_t *const p_ctrl, timer_cfg_t const *const p_cfg);

BSP_CMSE_NONSECURE_ENTRY fsp_err_t g_timer_periodic_callback_set_guard(timer_ctrl_t *const p_api_ctrl, void(*p_callback)(timer_callback_args_t *), void const *const p_context, timer_callback_args_t *const p_callback_memory);
#endif /* GUARD_H_ */
