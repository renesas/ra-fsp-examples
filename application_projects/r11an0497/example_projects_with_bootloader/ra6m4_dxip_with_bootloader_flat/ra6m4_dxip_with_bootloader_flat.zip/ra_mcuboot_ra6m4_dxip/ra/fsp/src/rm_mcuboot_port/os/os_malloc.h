/** Not required, using malloc from standard library. */
